from setuptools import setup, find_packages


# with open('README.md') as f:
#     long_description = f.read()
# def get_install_requires():
#     with open('requirements.txt') as reqs_file:
#         reqs = [line.rstrip() for line in reqs_file.readlines()]
#     return reqs

# def get_version():
#     with open('version.txt') as ver_file:
#         version_str = ver_file.readline().rstrip()
#     return version_str


#    python setupML.py sdist bdist_wheel

setup(
    name='ennoml',
    version="0.0.1",
    description='Enn_Custom_ML_Package_for_Product_Identification',
    long_description="Read_Me",
    long_description_content_type='text/markdown',
    license='ENN_0.1',
    packages=['.ennoml','.ennoml.data','.ennoml.testing','.ennoml.training','.ennoml.util','.ennoml.models'],
    # package_dir={'.Enno'},
    author='Utkarsh_Shrivastav',
    install_requires=['tensorflow-gpu>=2.3,<2.7','pandas','Pillow','opencv-python','numpy', 'scikit-image','xlswriter'],
    python_requires='>=3.6,<3.10'
    # data_files=[('Enno', ['Enno\\data.zip'])],
    # packages=find_packages(include=["tests", "platformtest","GLIM*"]),
    #data_files=[('aiftextclassifier', ['GLIM/data/catalogs.zip', 'GLIM/additional.zip'])],   ,'Enno\\models','Enno\\testing','Enno\\training','Enno\\util'
    # include_package_data=True
    # classifiers=[
    #     'Programming Language :: Python :: 3',
    #     'License :: Other/Proprietary License',
    #     'Operating System :: POSIX :: Linux',
    #     'Operating System :: MacOS :: MacOS X',
    #     'Environment :: Console',
    #     'Topic :: Text Processing',
    #     'Topic :: Text Processing :: Linguistic',
    #     'Development Status :: 1 - Planning'
    # ],
    # dependency_links=[
    #     'http://nexus.wdf.sap.corp:8081/nexus/content/groups/build.releases.pypi/simple/'
    # ],
)